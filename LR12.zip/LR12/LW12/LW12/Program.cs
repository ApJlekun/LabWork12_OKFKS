using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

var builder = WebApplication.CreateBuilder(args);

var gitHubAuthSettings = builder.Configuration.GetSection("GitHubAuth");
builder.Services.Configure<GitHubAuthSettings>(gitHubAuthSettings);

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
   
    options.DefaultChallengeScheme = "GitHub"; 
})
.AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, options =>
{
    options.Cookie.Name = "GitHubAuthCookie"; 
    options.LoginPath = "/login"; 
    options.LogoutPath = "/logout"; 
    options.AccessDeniedPath = "/access-denied";
    options.SlidingExpiration = true; 
    options.ExpireTimeSpan = TimeSpan.FromMinutes(builder.Configuration.GetValue<int>("GitHubAuth:AccessTokenExpirationMinutes", 60));
})
.AddOAuth("GitHub", options =>
{
    var gitHubConfig = gitHubAuthSettings.Get<GitHubAuthSettings>() ?? new GitHubAuthSettings();

    options.ClientId = gitHubConfig.ClientId;
    options.ClientSecret = gitHubConfig.ClientSecret;
    options.CallbackPath = gitHubConfig.CallbackPath;
    options.AuthorizationEndpoint = gitHubConfig.AuthorizationEndpoint; 
    options.TokenEndpoint = gitHubConfig.TokenEndpoint;      
    options.UserInformationEndpoint = gitHubConfig.UserInformationEndpoint; 

    options.SaveTokens = true; 
    options.Scope.Add("read:user"); 
    options.Scope.Add("user:email"); 

    options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
    options.ClaimActions.MapJsonKey(ClaimTypes.Name, "login"); 
    options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email"); 
    options.ClaimActions.MapJsonKey("urn:github:name", "name"); 
    options.ClaimActions.MapJsonKey("urn:github:url", "html_url"); 
    options.ClaimActions.MapJsonKey("urn:github:avatar_url", "avatar_url"); 
    options.ClaimActions.MapJsonKey("urn:github:company", "company"); 
    options.ClaimActions.MapJsonKey("urn:github:location", "location");

    options.Events = new OAuthEvents
    {
        OnCreatingTicket = async context =>
        {
            
            var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", context.AccessToken);
            request.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            request.Headers.UserAgent.ParseAdd(gitHubConfig.AppName);

            var response = await context.Backchannel.SendAsync(request);
            response.EnsureSuccessStatusCode();

            using var userDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var userRootElement = userDocument.RootElement;

            context.RunClaimActions(userRootElement);

        }
    };
});

builder.Services.AddAuthorization();
builder.Services.AddControllers();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();

app.Use(async (context, next) => 
{
    context.Response.ContentType = "text/html; charset=utf-8";
    await next();
});

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapGet("/", async context =>
{
    var user = context.User; 

    context.Response.ContentType = "text/html; charset=utf-8";

    if (user.Identity?.IsAuthenticated ?? false)
    {
        var userId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "N/A";
        var userName = user.FindFirst(ClaimTypes.Name)?.Value ?? "N/A";
        var userEmail = user.FindFirst(ClaimTypes.Email)?.Value ?? "Email �� ������������";
        var githubUrl = user.FindFirst("urn:github:url")?.Value ?? "#";
        var avatarUrl = user.FindFirst("urn:github:avatar_url")?.Value ?? "";

        string html = $@"
            <h1>������, {userName}!</h1>
            <p>��� GitHub ID: {userId}</p>
            <p>��� Email: {userEmail}</p>";

        if (!string.IsNullOrEmpty(avatarUrl))
        {
            html += $"<p><img src='{avatarUrl}' alt='������' width='100' height='100'></p>";
        }

        html += $@"
            <p><a href='{githubUrl}' target='_blank'>������� GitHub</a></p>
            <p><a href='/logout'>�����</a></p>";

        await context.Response.WriteAsync(html);
    }
    else
    {
        string html = @"
            <h1>����� ����������!</h1>
            <p><a href=""/login"">����� � ������� GitHub</a></p>";
        await context.Response.WriteAsync(html);
    }
});

app.MapGet("/login", async context =>
{
    await context.ChallengeAsync("GitHub", new AuthenticationProperties { RedirectUri = "/" }); 
});

app.MapGet("/logout", async context =>
{
    await context.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    context.Response.Redirect("/"); 
});
app.Run();

[ApiController]
[Route("api/user")]
[Authorize] 
public class UserController : ControllerBase
{
    [HttpGet("info")]
    public IActionResult GetUserInfo()
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "N/A";
        var userName = User.FindFirst(ClaimTypes.Name)?.Value ?? "N/A";
        var userEmail = User.FindFirst(ClaimTypes.Email)?.Value ?? "Email �� ������������";
        var githubName = User.FindFirst("urn:github:name")?.Value ?? "N/A";
        var githubUrl = User.FindFirst("urn:github:url")?.Value ?? "#";
        var avatarUrl = User.FindFirst("urn:github:avatar_url")?.Value ?? "";

        return Ok(new
        {
            GitHubId = userId,
            GitHubLogin = userName,
            FullName = githubName,
            Email = userEmail,
            GitHubProfileUrl = githubUrl,
            AvatarUrl = avatarUrl,
            
        });
    }
}


public class GitHubAuthSettings
{
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string CallbackPath { get; set; } = string.Empty;
    public string AuthorizationEndpoint { get; set; } = string.Empty;
    public string TokenEndpoint { get; set; } = string.Empty;
    public string UserInformationEndpoint { get; set; } = string.Empty;
    public string AppName { get; set; } = string.Empty;
    public int AccessTokenExpirationMinutes { get; set; } = 60;
}
