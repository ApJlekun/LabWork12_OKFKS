﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LabWork12.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles= "Admin")]
    public class AdminController : ControllerBase
    {
        [HttpGet]
        public IActionResult ManageUsers()
        {
            return Ok("Добро пожаловать в панель администратора! Здесь вы можете управлять пользователями.");
        }
    }
}
