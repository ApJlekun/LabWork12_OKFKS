﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace LabWork12.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly List<User> _users = new List<User>
        {
            new User { Login = "admin", Password = "password123", Role = "Admin" },
            new User { Login = "user1", Password = "userpass", Role = "User" },
            new User { Login = "user2", Password = "anotherpass", Role = "User" }
        };

        [HttpPost("login")]
        public IActionResult Login([FromBody] User loginData)
        {
            var user = _users.FirstOrDefault(u => u.Login == loginData.Login && u.Password == loginData.Password);

            if (user == null)
            {
                return Unauthorized("Некорректное имя пользователя или пароль.");
            }

            var token = GenerateJwtToken(user.Login, user.Role);

            return Ok(new { token });
        }

        private string GenerateJwtToken(string username, string role)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("super_secret_jwt_key_1234567890_");

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim(ClaimTypes.NameIdentifier, username),
                new Claim(ClaimTypes.Role, role)
            }),
                Expires = DateTime.UtcNow.AddMinutes(30),
                Issuer = "IP KOREEV",
                Audience = "ispp.com",
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
