﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace LabWork12.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpGet("profile")]
        public IActionResult GetUserProfile()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var role = User.FindFirst(ClaimTypes.Role)?.Value;

            return Ok($"Ваш профиль. Пользователь: {userId}, Роль: {role}");
        }

        [HttpGet("publicInfo")]
        [AllowAnonymous]
        public IActionResult GetPublicInfo()
        {
            return Ok("Эта информация доступна всем.");
        }

        [HttpGet("sensitiveData")]
        [Authorize(Roles = "User,Admin")]
        public IActionResult GetSensitiveData()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return Ok($"Это конфиденциальные данные для пользователей. Пользователь: {userId}");
        }
    }
}
